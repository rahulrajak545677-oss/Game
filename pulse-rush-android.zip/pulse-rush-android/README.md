# Pulse Rush (Android)

A WebView app that wraps the Pulse Rush game (`app/src/main/assets/index.html`).
GitHub builds the APK for you, so you do not need Android Studio.

## Get your APK in 5 steps

1. Unzip this file. Open the `pulse-rush-android` folder.
2. On GitHub, create a new repository (private is fine).
3. Click **Add file > Upload files**, then drag in everything inside the folder, including the `.github` folder, and commit to `main`.
   If `.github` will not upload, choose **Add file > Create new file**, type `.github/workflows/build-apk.yml` as the name and paste in the contents of that file.
4. Open the **Actions** tab. The **Build Android APK** run starts by itself (or click **Run workflow**). It takes about 3 to 5 minutes.
5. Open the finished run and download **PulseRush-debug-apk** from Artifacts. Unzip it and install `app-debug.apk` on any Android phone.

Using git instead:

```
git init && git add . && git commit -m "Pulse Rush"
git branch -M main
git remote add origin https://github.com/YOU/pulse-rush.git
git push -u origin main
```

## Before you sell it

- **App id:** change `applicationId` in `app/build.gradle` to your own, for example `com.yourchannel.pulserush`.
- **Version:** raise `versionCode` by 1 and update `versionName` for every update you upload.
- **Name and logo:** the name is in `app/src/main/res/values/strings.xml`. The icon is in `res/drawable/ic_launcher_*.xml`.
- **Game settings:** the `CONFIG` block near the top of `assets/index.html` holds the title, tagline, BPM, skins and prices. It also has `onRunStart`, `onRunEnd` and `onShare` hooks for ads or analytics.

## Signed release (needed for Google Play)

The debug APK installs anywhere but cannot go on Google Play. For a signed release APK and AAB:

1. Make a key (keep this file safe, you cannot replace it later):
   `keytool -genkeypair -v -keystore release.jks -alias pulserush -keyalg RSA -keysize 2048 -validity 10000`
2. Turn it into text: `base64 -w0 release.jks` (on Mac: `base64 -i release.jks`).
3. In your repo go to **Settings > Secrets and variables > Actions** and add four secrets:
   `KEYSTORE_BASE64` (the text from step 2), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (`pulserush`), `KEY_PASSWORD`.
4. Run the workflow again. It now also uploads **PulseRush-release** with the signed `.apk` and `.aab`. Google Play takes the `.aab`.

## Notes

- Fonts load from Google Fonts when the phone is online and fall back to system fonts offline. Everything else works offline.
- Back button: pauses a run, closes panels, or goes home. On the home screen press it twice to exit.
- Android 8.0 and newer is supported.
